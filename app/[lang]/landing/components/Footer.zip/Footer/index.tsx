import Link from 'next/link';
import style from './index.module.scss';


const siteMap = [
	{
		"category": "About",
		"items": [
			{ "name": "About Bossjob", "link": "https://bossjob.com/about" },
			{ "name": "Terms & conditions", "link": "https://bossjob.com/terms" },
			{ "name": "Legal", "link": "https://bossjob.com/legal" },
			{ "name": "BossPoints", "link": "https://bossjob.com/bosspoints" },
			{ "name": "FAQ", "link": "https://bossjob.com/faq" },
			{ "name": "Sitemap", "link": "https://bossjob.com/sitemap" }
		]
	},
	{
		"category": "Talents",
		"items": [
			{ "name": "All jobs", "link": "https://bossjob.com/jobs" },
			{ "name": "Create job alert", "link": "https://bossjob.com/alert" },
			{ "name": "Create resume", "link": "https://bossjob.com/resume" },
			{ "name": "Career guide", "link": "https://bossjob.com/career-guide" },
			{ "name": "Courses", "link": "https://bossjob.com/courses" }
		]
	},
	{
		"category": "Recruiter",
		"items": [
			{ "name": "Get started", "link": "https://bossjob.com/recruiter" }
		]
	},
	{
		"category": "Popular Jobs",
		"items": [
			{ "name": "Jobs in Manila", "link": "https://bossjob.com/jobs/manila" },
			{ "name": "Jobs in Makati", "link": "https://bossjob.com/jobs/makati" },
			{ "name": "Jobs in Cebu", "link": "https://bossjob.com/jobs/cebu" },
			{ "name": "IT jobs", "link": "https://bossjob.com/jobs/it" },
			{ "name": "Finance jobs", "link": "https://bossjob.com/jobs/finance" },
			{ "name": "Customer service jobs", "link": "https://bossjob.com/jobs/customer-service" },
			{ "name": "BPO jobs", "link": "https://bossjob.com/jobs/bpo" },
			{ "name": "Sales jobs", "link": "https://bossjob.com/jobs/sales" },
			{ "name": "Healthcare jobs", "link": "https://bossjob.com/jobs/healthcare" }
		]
	},

]

const follow_use  =  [
	{img: require('./facebook.svg').default.src, link: 'https://www.facebook.com/bossjob.ph'},
	{img: require('./inlink.svg').default.src, link: 'https://www.linkedin.com/company/bossjob'},
	{img: require('./ins.svg').default.src, link: 'https://www.instagram.com/bossjob.ph/'},
	{img: require('./youtube.svg').default.src, link: 'https://www.youtube.com/channel/UC4Z8mJXtZ6q8J8ZpZ6Z8Y0g'},
	{img: require('./twitter.svg').default.src, link: 'https://twitter.com/bossjobph'},
	{img: require('./tiktok.svg').default.src, link: 'https://www.tiktok.com/@bossjobph'},
]

const Footer = () =>{
	return <div className={style.footer_container}>
		<div className={style.footer_title}>
			Download Bossjob APP
		</div>
		<div className={style.footer_download}>
			<Link href={'https://apps.apple.com/sg/app/bossjob/id1592073585'} target={'_blank'}>
				<img src={require('./footer_download_apple.png').default.src} alt="_"/>
			</Link>
			<Link href={'https://play.google.com/store/apps/details?id=com.poseidon.bossjobapp'} target={'_blank'}>
				<img src={require('./footer_download_google.png').default.src} alt="_"/>
			</Link>
			<img className={style.qrcode} src={require('./footer_download_qrcode.png').default.src} alt="_"/>
		</div>
		<div className={style.footer_site_map}>
			{siteMap.map((item, index) => {
				return <div className={style.site_map_col} key={index}>
					<div className={style.site_map_title}>{item.category}</div>
					{item.items.map((_item,index)=>{
						return   (<Link className={style.site_map_link} target={'_blank'} href={_item.link} key={index}> {_item.name}</Link>)
					})}
				</div>
			})}
			<div className={style.site_map_col}>
				<div className={style.site_map_title}>Follow us</div>
				<div className={style.site_map_follow}>
					{follow_use.map((item, index) => {
						return <Link href={item.link} target={'_blank'} key={index}>
							<img src={item.img} alt="img"/>
						</Link>
					})}
				</div>
			</div>
		</div>
		<div className={style.site_copy_right}>
			Copyright © 2022  Singapore: Yolo Technology Pte Ltd. All Rights Reserved.
			Philippines: Etos Adtech Corporation
		</div>
		<img src={require('./bg.svg').default.src} alt={'bg'} className={style.bg}/>

	</div>
}

export default Footer;









